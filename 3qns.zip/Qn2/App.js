function countoddness(N, A) {
	// Fix the code here  
	// Sorting the array A 
	A.sort((a, b) => a - b);
	let ans = 0;
	// Counting odd elements with duplicate value 
	for (let i = 0; i < N; i++) {
		if (A[i] % 2 != 0 && A[i] != A[i - 1]) {
			ans += 1;
		}
	}
	return ans;
}
const N = 10;
let A = [12,2,32,4,5,6,7,8,9,10]

// for (let j = 0; j < N; j++) {

// 	A.push(parseInt(gets().trim()));

// }

const result = countoddness(N, A);
console.log(result);
