"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Patient = void 0;
var Patient = /** @class */ (function () {
    function Patient(patientId, name, medicalCondition) {
        this.patientId = patientId;
        this.name = name;
        this.medicalCondition = medicalCondition;
    }
    Patient.prototype.displayDetails = function () {
        console.log("Patient ID: " + this.patientId + ", Name: " + this.name + ", Medical Condition: " + this.medicalCondition + ". ");
    };
    Patient.prototype.hasCondition = function (condition) {
        if (condition == this.medicalCondition)
            return "This patient has ".concat(condition, ".");
        else
            return "This patient does not have ".concat(condition, ".");
    };
    return Patient;
}());
exports.Patient = Patient;
