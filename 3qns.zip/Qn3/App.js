"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Patient_1 = require("./Patient");
var raja = new Patient_1.Patient(1, 'Raja', 'Asthma');
raja.displayDetails();
console.log(raja.hasCondition('Asthma'));
