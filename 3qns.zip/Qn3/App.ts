import { Patient } from "./Patient";

var raja:Patient=new Patient(1,'Raja','Asthma');
raja.displayDetails();
console.log(raja.hasCondition('Asthma'));
