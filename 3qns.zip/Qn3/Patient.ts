export class Patient{
    patientId:number;
    name:string;
    medicalCondition:string;

    constructor(patientId:number, name:string, medicalCondition:string){
        this.patientId=patientId;
        this.name=name;
        this.medicalCondition=medicalCondition;
    }

    displayDetails(){
        console.log("Patient ID: "+this.patientId+", Name: "+this.name+", Medical Condition: "+this.medicalCondition+". ");        
    }

    hasCondition(condition:string):string{
        if(condition==this.medicalCondition)
            return `This patient has ${condition}.`;
        else
            return `This patient does not have ${condition}.`
    }
}