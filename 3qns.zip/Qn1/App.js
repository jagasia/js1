function buggyHasUniqueCharacters(input){
//write your code here. This function should return true or false
}

function App(){
	var input="education";
	if(buggyHasUniqueCharacters(input))
		console.log("Correct");
	else
		console.log("InCorrect");
}